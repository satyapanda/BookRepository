﻿using System.Windows;

namespace Chapter4.Recipe9
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}
}