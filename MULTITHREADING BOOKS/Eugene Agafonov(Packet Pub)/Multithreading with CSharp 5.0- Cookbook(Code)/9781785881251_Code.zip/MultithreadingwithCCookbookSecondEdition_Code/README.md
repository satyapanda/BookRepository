Code samples for Multithreading with C# Cookbook - Second Edition
======================

Here are the code samples from my book Multithreading with C# Cookbook - Second Edition, converted to Visual Studio 2015 and Windows 10
You can use free Visual Studio 2015 Community to work with the code, it is able to run all the recipes provided. 

In case you have any suggestions or bug reports please send them to <a href="mailto:multithreading@eugeneagafonov.com">multithreading@eugeneagafonov.com</a>.
